class AppStrings {
  // App Title
  static const String appTitle = 'One-View Finance';
  static const String appTitleAr = 'التمويل بنظرة واحدة';

  // Navigation
  static const String home = 'Home';
  static const String homeAr = 'الرئيسية';
  static const String accounts = 'Accounts';
  static const String accountsAr = 'الحسابات';
  static const String transfer = 'Transfer';
  static const String transferAr = 'تحويل';
  static const String analytics = 'Analytics';
  static const String analyticsAr = 'التحليلات';
  static const String beneficiaries = 'Beneficiaries';
  static const String beneficiariesAr = 'المستفيدون';
  static const String settings = 'Settings';
  static const String settingsAr = 'الإعدادات';

  // Home Screen
  static const String totalBalance = 'Total Balance';
  static const String totalBalanceAr = 'الرصيد الإجمالي';
  static const String viewAccounts = 'View Accounts';
  static const String viewAccountsAr = 'عرض الحسابات';
  static const String quickTransfer = 'Transfer';
  static const String quickTransferAr = 'تحويل';
  static const String viewAnalytics = 'Analytics';
  static const String viewAnalyticsAr = 'التحليلات';
  static const String manageBeneficiaries = 'Beneficiaries';
  static const String manageBeneficiariesAr = 'المستفيدون';

  // Account Management
  static const String addAccount = 'Add Account';
  static const String addAccountAr = 'إضافة حساب';
  static const String editAccount = 'Edit Account';
  static const String editAccountAr = 'تعديل الحساب';
  static const String deleteAccount = 'Delete Account';
  static const String deleteAccountAr = 'حذف الحساب';
  static const String save = 'Save';
  static const String saveAr = 'حفظ';
  static const String cancel = 'Cancel';
  static const String cancelAr = 'إلغاء';
  static const String accountName = 'Account Name';
  static const String accountNameAr = 'اسم الحساب';
  static const String accountNumber = 'Account Number';
  static const String accountNumberAr = 'رقم الحساب';
  static const String accountType = 'Account Type';
  static const String accountTypeAr = 'نوع الحساب';
  static const String bankAccount = 'Bank Account';
  static const String bankAccountAr = 'حساب بنكي';
  static const String creditCard = 'Credit Card';
  static const String creditCardAr = 'بطاقة ائتمان';
  static const String childCard = 'Child Card';
  static const String childCardAr = 'بطاقة طفل';
  static const String spendingLimit = 'Spending Limit';
  static const String spendingLimitAr = 'حد الإنفاق';
  static const String usedAmount = 'Used';
  static const String usedAmountAr = 'المستخدم';
  static const String notifications = 'Notifications';
  static const String notificationsAr = 'الإشعارات';

  // Transfer
  static const String fromAccount = 'From Account';
  static const String fromAccountAr = 'من الحساب';
  static const String toAccount = 'To Account';
  static const String toAccountAr = 'إلى الحساب';
  static const String amount = 'Amount';
  static const String amountAr = 'المبلغ';
  static const String description = 'Description';
  static const String descriptionAr = 'الوصف';
  static const String confirmTransfer = 'Confirm Transfer';
  static const String confirmTransferAr = 'تأكيد التحويل';
  static const String transferSuccessful = 'Transfer Successful';
  static const String transferSuccessfulAr = 'تم التحويل بنجاح';
  static const String insufficientFunds = 'Insufficient Funds';
  static const String insufficientFundsAr = 'رصيد غير كافي';
  static const String invalidAmount = 'Invalid Amount';
  static const String invalidAmountAr = 'مبلغ غير صحيح';
  static const String sameAccountError = 'Cannot transfer to the same account';
  static const String sameAccountErrorAr = 'لا يمكن التحويل لنفس الحساب';
  static const String needTwoAccounts = 'You need at least two accounts to make a transfer';
  static const String needTwoAccountsAr = 'تحتاج إلى حسابين على الأقل لإجراء تحويل';

  // Analytics
  static const String spendingByCategory = 'Spending by Category';
  static const String spendingByCategoryAr = 'الإنفاق حسب الفئة';
  static const String totalSpent = 'Total Spent';
  static const String totalSpentAr = 'إجمالي المنفق';

  // Settings
  static const String darkTheme = 'Dark Theme';
  static const String darkThemeAr = 'الوضع المظلم';
  static const String language = 'Language';
  static const String languageAr = 'اللغة';
  static const String english = 'English';
  static const String englishAr = 'الإنجليزية';
  static const String arabic = 'Arabic';
  static const String arabicAr = 'العربية';
  static const String biometricAuth = 'Biometric Authentication';
  static const String biometricAuthAr = 'المصادقة البيومترية';
  static const String twoFactorAuth = 'Two-Factor Authentication';
  static const String twoFactorAuthAr = 'المصادقة الثنائية';

  // Transaction Categories
  static const String food = 'Food';
  static const String foodAr = 'طعام';
  static const String transportation = 'Transportation';
  static const String transportationAr = 'مواصلات';
  static const String shopping = 'Shopping';
  static const String shoppingAr = 'تسوق';
  static const String entertainment = 'Entertainment';
  static const String entertainmentAr = 'ترفيه';
  static const String utilities = 'Utilities';
  static const String utilitiesAr = 'مرافق';
  static const String healthcare = 'Healthcare';
  static const String healthcareAr = 'رعاية صحية';
  static const String education = 'Education';
  static const String educationAr = 'تعليم';
  static const String travel = 'Travel';
  static const String travelAr = 'سفر';
  static const String salary = 'Salary';
  static const String salaryAr = 'راتب';
  static const String transferCategory = 'Transfer';
  static const String transferCategoryAr = 'تحويل';
  static const String other = 'Other';
  static const String otherAr = 'أخرى';

  // Messages
  static const String noAccountsYet = 'No accounts yet. Add your first account to get started.';
  static const String noAccountsYetAr = 'لا توجد حسابات بعد. أضف حسابك الأول للبدء.';
  static const String deleteAccountConfirm = 'Are you sure you want to delete this account?';
  static const String deleteAccountConfirmAr = 'هل أنت متأكد من حذف هذا الحساب؟';
  static const String cannotDeleteLastAccount = 'Cannot delete the last account. You must have at least one account.';
  static const String cannotDeleteLastAccountAr = 'لا يمكن حذف الحساب الأخير. يجب أن يكون لديك حساب واحد على الأقل.';
  static const String notificationsEnabled = 'Notifications enabled';
  static const String notificationsEnabledAr = 'تم تفعيل الإشعارات';
  static const String notificationsDisabled = 'Notifications disabled';
  static const String notificationsDisabledAr = 'تم إلغاء الإشعارات';

  // Login
  static const String email = 'Email';
  static const String emailAr = 'البريد الإلكتروني';
  static const String password = 'Password';
  static const String passwordAr = 'كلمة المرور';
  static const String signIn = 'Sign In';
  static const String signInAr = 'تسجيل الدخول';
  static const String useBiometric = 'Use Biometric';
  static const String useBiometricAr = 'استخدام البصمة';

  // Currency
  static const String currency = 'KWD';
  static const String currencyAr = 'د.ك';

  // Time
  static const String today = 'Today';
  static const String todayAr = 'اليوم';
  static const String yesterday = 'Yesterday';
  static const String yesterdayAr = 'أمس';
  static const String thisWeek = 'This Week';
  static const String thisWeekAr = 'هذا الأسبوع';
  static const String thisMonth = 'This Month';
  static const String thisMonthAr = 'هذا الشهر';

  // Get localized string based on language
  static String getString(String key, bool isArabic) {
    final Map<String, Map<String, String>> strings = {
      'appTitle': {'en': appTitle, 'ar': appTitleAr},
      'home': {'en': home, 'ar': homeAr},
      'accounts': {'en': accounts, 'ar': accountsAr},
      'transfer': {'en': transfer, 'ar': transferAr},
      'analytics': {'en': analytics, 'ar': analyticsAr},
      'beneficiaries': {'en': beneficiaries, 'ar': beneficiariesAr},
      'settings': {'en': settings, 'ar': settingsAr},
      'totalBalance': {'en': totalBalance, 'ar': totalBalanceAr},
      'viewAccounts': {'en': viewAccounts, 'ar': viewAccountsAr},
      'quickTransfer': {'en': quickTransfer, 'ar': quickTransferAr},
      'viewAnalytics': {'en': viewAnalytics, 'ar': viewAnalyticsAr},
      'manageBeneficiaries': {'en': manageBeneficiaries, 'ar': manageBeneficiariesAr},
      'addAccount': {'en': addAccount, 'ar': addAccountAr},
      'editAccount': {'en': editAccount, 'ar': editAccountAr},
      'deleteAccount': {'en': deleteAccount, 'ar': deleteAccountAr},
      'save': {'en': save, 'ar': saveAr},
      'cancel': {'en': cancel, 'ar': cancelAr},
      'accountName': {'en': accountName, 'ar': accountNameAr},
      'accountNumber': {'en': accountNumber, 'ar': accountNumberAr},
      'accountType': {'en': accountType, 'ar': accountTypeAr},
      'bankAccount': {'en': bankAccount, 'ar': bankAccountAr},
      'creditCard': {'en': creditCard, 'ar': creditCardAr},
      'childCard': {'en': childCard, 'ar': childCardAr},
      'spendingLimit': {'en': spendingLimit, 'ar': spendingLimitAr},
      'usedAmount': {'en': usedAmount, 'ar': usedAmountAr},
      'notifications': {'en': notifications, 'ar': notificationsAr},
      'fromAccount': {'en': fromAccount, 'ar': fromAccountAr},
      'toAccount': {'en': toAccount, 'ar': toAccountAr},
      'amount': {'en': amount, 'ar': amountAr},
      'description': {'en': description, 'ar': descriptionAr},
      'confirmTransfer': {'en': confirmTransfer, 'ar': confirmTransferAr},
      'transferSuccessful': {'en': transferSuccessful, 'ar': transferSuccessfulAr},
      'insufficientFunds': {'en': insufficientFunds, 'ar': insufficientFundsAr},
      'invalidAmount': {'en': invalidAmount, 'ar': invalidAmountAr},
      'sameAccountError': {'en': sameAccountError, 'ar': sameAccountErrorAr},
      'needTwoAccounts': {'en': needTwoAccounts, 'ar': needTwoAccountsAr},
      'spendingByCategory': {'en': spendingByCategory, 'ar': spendingByCategoryAr},
      'totalSpent': {'en': totalSpent, 'ar': totalSpentAr},
      'darkTheme': {'en': darkTheme, 'ar': darkThemeAr},
      'language': {'en': language, 'ar': languageAr},
      'english': {'en': english, 'ar': englishAr},
      'arabic': {'en': arabic, 'ar': arabicAr},
      'biometricAuth': {'en': biometricAuth, 'ar': biometricAuthAr},
      'twoFactorAuth': {'en': twoFactorAuth, 'ar': twoFactorAuthAr},
      'food': {'en': food, 'ar': foodAr},
      'transportation': {'en': transportation, 'ar': transportationAr},
      'shopping': {'en': shopping, 'ar': shoppingAr},
      'entertainment': {'en': entertainment, 'ar': entertainmentAr},
      'utilities': {'en': utilities, 'ar': utilitiesAr},
      'healthcare': {'en': healthcare, 'ar': healthcareAr},
      'education': {'en': education, 'ar': educationAr},
      'travel': {'en': travel, 'ar': travelAr},
      'salary': {'en': salary, 'ar': salaryAr},
      'transferCategory': {'en': transferCategory, 'ar': transferCategoryAr},
      'other': {'en': other, 'ar': otherAr},
      'noAccountsYet': {'en': noAccountsYet, 'ar': noAccountsYetAr},
      'deleteAccountConfirm': {'en': deleteAccountConfirm, 'ar': deleteAccountConfirmAr},
      'cannotDeleteLastAccount': {'en': cannotDeleteLastAccount, 'ar': cannotDeleteLastAccountAr},
      'notificationsEnabled': {'en': notificationsEnabled, 'ar': notificationsEnabledAr},
      'notificationsDisabled': {'en': notificationsDisabled, 'ar': notificationsDisabledAr},
      'email': {'en': email, 'ar': emailAr},
      'password': {'en': password, 'ar': passwordAr},
      'signIn': {'en': signIn, 'ar': signInAr},
      'useBiometric': {'en': useBiometric, 'ar': useBiometricAr},
      'currency': {'en': currency, 'ar': currencyAr},
      'today': {'en': today, 'ar': todayAr},
      'yesterday': {'en': yesterday, 'ar': yesterdayAr},
      'thisWeek': {'en': thisWeek, 'ar': thisWeekAr},
      'thisMonth': {'en': thisMonth, 'ar': thisMonthAr},
    };

    return strings[key]?[isArabic ? 'ar' : 'en'] ?? key;
  }
}

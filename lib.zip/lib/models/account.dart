import 'package:final_project_unicode/models/transaction.dart';

enum AccountType { bank, credit, child }

class Account {
  final String id;
  final String name;
  final String maskedNumber;
  final AccountType type;
  final double balance;
  final String currency;
  final List<Transaction> transactions;
  final double? spendingLimit; // For child cards
  final double? usedAmount; // For child cards
  final bool notificationsEnabled; // For child cards

  Account({
    required this.id,
    required this.name,
    required this.maskedNumber,
    required this.type,
    required this.balance,
    this.currency = 'KWD',
    this.transactions = const [],
    this.spendingLimit,
    this.usedAmount,
    this.notificationsEnabled = true,
  });

  Account copyWith({
    String? id,
    String? name,
    String? maskedNumber,
    AccountType? type,
    double? balance,
    String? currency,
    List<Transaction>? transactions,
    double? spendingLimit,
    double? usedAmount,
    bool? notificationsEnabled,
  }) {
    return Account(
      id: id ?? this.id,
      name: name ?? this.name,
      maskedNumber: maskedNumber ?? this.maskedNumber,
      type: type ?? this.type,
      balance: balance ?? this.balance,
      currency: currency ?? this.currency,
      transactions: transactions ?? this.transactions,
      spendingLimit: spendingLimit ?? this.spendingLimit,
      usedAmount: usedAmount ?? this.usedAmount,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
    );
  }

  double get availableBalance {
    if (type == AccountType.credit) {
      return spendingLimit! - usedAmount!;
    }
    return balance;
  }

  double get progressPercentage {
    if (spendingLimit == null || spendingLimit == 0) return 0;
    return (usedAmount ?? 0) / spendingLimit!;
  }

  bool get isChild => type == AccountType.child;
  bool get isCredit => type == AccountType.credit;
  bool get isBank => type == AccountType.bank;
}

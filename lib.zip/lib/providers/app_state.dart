import 'package:flutter/material.dart';
import '../models/account.dart';
import '../models/transaction.dart';
import '../constants/app_strings.dart';

class AppState extends ChangeNotifier {
  // Settings
  bool _isDarkMode = false;
  bool _isArabic = false;
  bool _useBiometric = false;
  bool _useTwoFactor = false;

  // Data
  List<Account> _accounts = [];
  List<Transaction> _allTransactions = [];

  // Getters
  bool get isDarkMode => _isDarkMode;
  bool get isArabic => _isArabic;
  bool get useBiometric => _useBiometric;
  bool get useTwoFactor => _useTwoFactor;
  List<Account> get accounts => _accounts;
  List<Transaction> get allTransactions => _allTransactions;

  // Computed getters
  double get totalBalance {
    return _accounts
        .where((account) => account.type != AccountType.credit)
        .fold(0.0, (sum, account) => sum + account.balance);
  }

  List<Account> get childAccounts {
    return _accounts.where((account) => account.type == AccountType.child).toList();
  }

  List<Account> get transferableAccounts {
    return _accounts.where((account) => account.type != AccountType.child).toList();
  }

  // Initialize with mock data
  AppState() {
    _initializeMockData();
  }

  void _initializeMockData() {
    // Create mock accounts
    final account1 = Account(
      id: '1',
      name: 'Main Bank Account',
      maskedNumber: '****1234',
      type: AccountType.bank,
      balance: 5000.0,
      transactions: [],
    );

    final account2 = Account(
      id: '2',
      name: 'Credit Card',
      maskedNumber: '****5678',
      type: AccountType.credit,
      balance: -1500.0,
      spendingLimit: 5000.0,
      usedAmount: 1500.0,
      transactions: [],
    );

    final account3 = Account(
      id: '3',
      name: 'Savings Account',
      maskedNumber: '****9012',
      type: AccountType.bank,
      balance: 2500.0,
      transactions: [],
    );

    final childAccount1 = Account(
      id: '4',
      name: 'Ahmad\'s Card',
      maskedNumber: '****3456',
      type: AccountType.child,
      balance: 250.0,
      spendingLimit: 500.0,
      usedAmount: 250.0,
      notificationsEnabled: true,
      transactions: [],
    );

    final childAccount2 = Account(
      id: '5',
      name: 'Fatima\'s Card',
      maskedNumber: '****7890',
      type: AccountType.child,
      balance: 180.0,
      spendingLimit: 300.0,
      usedAmount: 120.0,
      notificationsEnabled: false,
      transactions: [],
    );

    _accounts = [account1, account2, account3, childAccount1, childAccount2];

    // Create mock transactions
    _allTransactions = [
      Transaction(
        id: '1',
        dateTime: DateTime.now().subtract(const Duration(days: 1)),
        description: 'Grocery Shopping',
        amount: -85.50,
        category: TransactionCategory.food,
        accountId: '1',
      ),
      Transaction(
        id: '2',
        dateTime: DateTime.now().subtract(const Duration(days: 2)),
        description: 'Gas Station',
        amount: -45.00,
        category: TransactionCategory.transportation,
        accountId: '1',
      ),
      Transaction(
        id: '3',
        dateTime: DateTime.now().subtract(const Duration(days: 3)),
        description: 'Salary Deposit',
        amount: 3000.00,
        category: TransactionCategory.salary,
        accountId: '1',
      ),
      Transaction(
        id: '4',
        dateTime: DateTime.now().subtract(const Duration(days: 4)),
        description: 'Online Shopping',
        amount: -120.00,
        category: TransactionCategory.shopping,
        accountId: '2',
      ),
      Transaction(
        id: '5',
        dateTime: DateTime.now().subtract(const Duration(days: 5)),
        description: 'Restaurant',
        amount: -65.00,
        category: TransactionCategory.food,
        accountId: '2',
      ),
      Transaction(
        id: '6',
        dateTime: DateTime.now().subtract(const Duration(days: 6)),
        description: 'Movie Tickets',
        amount: -35.00,
        category: TransactionCategory.entertainment,
        accountId: '4',
      ),
      Transaction(
        id: '7',
        dateTime: DateTime.now().subtract(const Duration(days: 7)),
        description: 'School Supplies',
        amount: -45.00,
        category: TransactionCategory.education,
        accountId: '5',
      ),
    ];

    // Add transactions to accounts
    _updateAccountTransactions();
  }

  void _updateAccountTransactions() {
    for (var account in _accounts) {
      final accountTransactions = _allTransactions
          .where((transaction) => transaction.accountId == account.id)
          .toList();
      
      final updatedAccount = account.copyWith(transactions: accountTransactions);
      final index = _accounts.indexWhere((a) => a.id == account.id);
      if (index != -1) {
        _accounts[index] = updatedAccount;
      }
    }
  }

  // Settings methods
  void toggleDarkMode() {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
  }

  void toggleLanguage() {
    _isArabic = !_isArabic;
    notifyListeners();
  }

  void toggleBiometric() {
    _useBiometric = !_useBiometric;
    notifyListeners();
  }

  void toggleTwoFactor() {
    _useTwoFactor = !_useTwoFactor;
    notifyListeners();
  }

  // Account methods
  void addAccount(Account account) {
    _accounts.add(account);
    notifyListeners();
  }

  void updateAccount(Account account) {
    final index = _accounts.indexWhere((a) => a.id == account.id);
    if (index != -1) {
      _accounts[index] = account;
      notifyListeners();
    }
  }

  void deleteAccount(String accountId) {
    if (_accounts.length > 1) {
      _accounts.removeWhere((account) => account.id == accountId);
      _allTransactions.removeWhere((transaction) => transaction.accountId == accountId);
      _updateAccountTransactions();
      notifyListeners();
    }
  }

  Account? getAccountById(String id) {
    try {
      return _accounts.firstWhere((account) => account.id == id);
    } catch (e) {
      return null;
    }
  }

  // Transaction methods
  void addTransaction(Transaction transaction) {
    _allTransactions.add(transaction);
    _updateAccountTransactions();
    notifyListeners();
  }

  List<Transaction> getTransactionsForAccount(String accountId) {
    return _allTransactions
        .where((transaction) => transaction.accountId == accountId)
        .toList()
      ..sort((a, b) => b.dateTime.compareTo(a.dateTime));
  }

  // Transfer methods
  bool canTransfer(String fromAccountId, String toAccountId, double amount) {
    if (fromAccountId == toAccountId) return false;
    
    final fromAccount = getAccountById(fromAccountId);
    if (fromAccount == null) return false;
    
    if (fromAccount.type == AccountType.credit) {
      return fromAccount.availableBalance >= amount;
    } else {
      return fromAccount.balance >= amount;
    }
  }

  void performTransfer(String fromAccountId, String toAccountId, double amount, String description) {
    if (!canTransfer(fromAccountId, toAccountId, amount)) return;

    final fromAccount = getAccountById(fromAccountId);
    final toAccount = getAccountById(toAccountId);
    
    if (fromAccount == null || toAccount == null) return;

    // Update account balances
    final updatedFromAccount = fromAccount.copyWith(
      balance: fromAccount.balance - amount,
      usedAmount: fromAccount.type == AccountType.credit 
          ? (fromAccount.usedAmount ?? 0) + amount 
          : fromAccount.usedAmount,
    );

    final updatedToAccount = toAccount.copyWith(
      balance: toAccount.balance + amount,
    );

    updateAccount(updatedFromAccount);
    updateAccount(updatedToAccount);

    // Add transfer transactions
    final transferId = DateTime.now().millisecondsSinceEpoch.toString();
    
    addTransaction(Transaction(
      id: '${transferId}_from',
      dateTime: DateTime.now(),
      description: 'Transfer to ${toAccount.name}',
      amount: -amount,
      category: TransactionCategory.transfer,
      accountId: fromAccountId,
    ));

    addTransaction(Transaction(
      id: '${transferId}_to',
      dateTime: DateTime.now(),
      description: 'Transfer from ${fromAccount.name}',
      amount: amount,
      category: TransactionCategory.transfer,
      accountId: toAccountId,
    ));
  }

  // Child account methods
  void updateChildSpendingLimit(String accountId, double newLimit) {
    final account = getAccountById(accountId);
    if (account != null && account.type == AccountType.child) {
      final updatedAccount = account.copyWith(spendingLimit: newLimit);
      updateAccount(updatedAccount);
    }
  }

  void toggleChildNotifications(String accountId) {
    final account = getAccountById(accountId);
    if (account != null && account.type == AccountType.child) {
      final updatedAccount = account.copyWith(
        notificationsEnabled: !account.notificationsEnabled,
      );
      updateAccount(updatedAccount);
    }
  }

  // Analytics methods
  Map<TransactionCategory, double> getSpendingByCategory() {
    final Map<TransactionCategory, double> categoryTotals = {};
    
    for (final transaction in _allTransactions) {
      if (transaction.isExpense) {
        final category = transaction.category;
        categoryTotals[category] = (categoryTotals[category] ?? 0) + transaction.amount.abs();
      }
    }
    
    return categoryTotals;
  }

  // Utility methods
  String getLocalizedString(String key) {
    return AppStrings.getString(key, _isArabic);
  }

  String formatCurrency(double amount) {
    final currency = _isArabic ? 'د.ك' : 'KWD';
    return '${amount.toStringAsFixed(2)} $currency';
  }
}

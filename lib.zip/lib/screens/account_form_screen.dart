import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/account.dart';
import '../providers/app_state.dart';
import '../constants/app_colors.dart';

class AccountFormScreen extends StatefulWidget {
  final Account? account; // null for new account, non-null for editing

  const AccountFormScreen({super.key, this.account});

  @override
  State<AccountFormScreen> createState() => _AccountFormScreenState();
}

class _AccountFormScreenState extends State<AccountFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _numberController = TextEditingController();
  final _spendingLimitController = TextEditingController();
  
  AccountType _selectedType = AccountType.bank;
  bool _notificationsEnabled = true;

  @override
  void initState() {
    super.initState();
    if (widget.account != null) {
      // Editing existing account
      _nameController.text = widget.account!.name;
      _numberController.text = widget.account!.maskedNumber;
      _selectedType = widget.account!.type;
      _notificationsEnabled = widget.account!.notificationsEnabled;
      if (widget.account!.spendingLimit != null) {
        _spendingLimitController.text = widget.account!.spendingLimit!.toString();
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _numberController.dispose();
    _spendingLimitController.dispose();
    super.dispose();
  }

  void _saveAccount() {
    if (!_formKey.currentState!.validate()) return;

    final appState = context.read<AppState>();
    final accountId = widget.account?.id ?? DateTime.now().millisecondsSinceEpoch.toString();
    
    final account = Account(
      id: accountId,
      name: _nameController.text.trim(),
      maskedNumber: _numberController.text.trim(),
      type: _selectedType,
      balance: widget.account?.balance ?? 0.0,
      spendingLimit: _selectedType == AccountType.credit || _selectedType == AccountType.child
          ? double.tryParse(_spendingLimitController.text) ?? 0.0
          : null,
      usedAmount: widget.account?.usedAmount ?? 0.0,
      notificationsEnabled: _notificationsEnabled,
      transactions: widget.account?.transactions ?? [],
    );

    if (widget.account != null) {
      appState.updateAccount(account);
    } else {
      appState.addAccount(account);
    }

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, appState, child) {
        final isEditing = widget.account != null;
        
        return Scaffold(
          appBar: AppBar(
            title: Text(
              isEditing 
                  ? appState.getLocalizedString('editAccount')
                  : appState.getLocalizedString('addAccount'),
            ),
            actions: [
              if (isEditing)
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: _showDeleteDialog,
                ),
            ],
          ),
          body: Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // Account Name
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: appState.getLocalizedString('accountName'),
                    prefixIcon: const Icon(Icons.account_balance_wallet),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter account name';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Account Number
                TextFormField(
                  controller: _numberController,
                  decoration: InputDecoration(
                    labelText: appState.getLocalizedString('accountNumber'),
                    prefixIcon: const Icon(Icons.credit_card),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter account number';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Account Type
                DropdownButtonFormField<AccountType>(
                  initialValue: _selectedType,
                  decoration: InputDecoration(
                    labelText: appState.getLocalizedString('accountType'),
                    prefixIcon: const Icon(Icons.category),
                  ),
                  items: [
                    DropdownMenuItem(
                      value: AccountType.bank,
                      child: Text(appState.getLocalizedString('bankAccount')),
                    ),
                    DropdownMenuItem(
                      value: AccountType.credit,
                      child: Text(appState.getLocalizedString('creditCard')),
                    ),
                    DropdownMenuItem(
                      value: AccountType.child,
                      child: Text(appState.getLocalizedString('childCard')),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _selectedType = value!;
                    });
                  },
                ),
                const SizedBox(height: 16),

                // Spending Limit (for credit and child cards)
                if (_selectedType == AccountType.credit || _selectedType == AccountType.child) ...[
                  TextFormField(
                    controller: _spendingLimitController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: appState.getLocalizedString('spendingLimit'),
                      prefixIcon: const Icon(Icons.attach_money),
                      suffixText: appState.getLocalizedString('currency'),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Please enter spending limit';
                      }
                      final limit = double.tryParse(value);
                      if (limit == null || limit <= 0) {
                        return 'Please enter a valid amount';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                ],

                // Notifications (for child cards)
                if (_selectedType == AccountType.child) ...[
                  SwitchListTile(
                    title: Text(appState.getLocalizedString('notifications')),
                    subtitle: const Text('Enable notifications for this child card'),
                    value: _notificationsEnabled,
                    onChanged: (value) {
                      setState(() {
                        _notificationsEnabled = value;
                      });
                    },
                    activeThumbColor: AppColors.primaryBlue,
                  ),
                  const SizedBox(height: 16),
                ],

                // Save Button
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: _saveAccount,
                    child: Text(
                      appState.getLocalizedString('save'),
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showDeleteDialog() {
    final appState = context.read<AppState>();
    
    if (appState.accounts.length <= 1) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(appState.getLocalizedString('cannotDeleteLastAccount')),
          backgroundColor: AppColors.error,
        ),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(appState.getLocalizedString('deleteAccount')),
        content: Text(appState.getLocalizedString('deleteAccountConfirm')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(appState.getLocalizedString('cancel')),
          ),
          ElevatedButton(
            onPressed: () {
              appState.deleteAccount(widget.account!.id);
              Navigator.pop(context); // Close dialog
              Navigator.pop(context); // Close form screen
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.error,
              foregroundColor: Colors.white,
            ),
            child: Text(appState.getLocalizedString('deleteAccount')),
          ),
        ],
      ),
    );
  }
}

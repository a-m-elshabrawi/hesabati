import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/transaction.dart';
import '../providers/app_state.dart';
import '../constants/app_colors.dart';
import '../widgets/currency_text.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, appState, child) {
        final spendingByCategory = appState.getSpendingByCategory();
        final totalSpent = spendingByCategory.values.fold(0.0, (sum, amount) => sum + amount);
        
        return Scaffold(
          appBar: AppBar(
            title: Text(appState.getLocalizedString('analytics')),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Total Spent Card
                _buildTotalSpentCard(context, appState, totalSpent),
                const SizedBox(height: 24),
                
                // Spending by Category
                _buildSpendingByCategory(context, appState, spendingByCategory, totalSpent),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildTotalSpentCard(BuildContext context, AppState appState, double totalSpent) {
    return Card(
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppColors.primaryBlue, AppColors.primaryBlueLight],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(
              appState.getLocalizedString('totalSpent'),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w500,
                
              ),
            ),
            const SizedBox(height: 8),
            CurrencyText(
              amount: totalSpent,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 32,
                fontWeight: FontWeight.bold,
                
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSpendingByCategory(
    BuildContext context, 
    AppState appState, 
    Map<TransactionCategory, double> spendingByCategory,
    double totalSpent,
  ) {
    if (spendingByCategory.isEmpty) {
      return _buildEmptyAnalytics(context, appState);
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          appState.getLocalizedString('spendingByCategory'),
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 16),
        
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: spendingByCategory.length,
          itemBuilder: (context, index) {
            final category = spendingByCategory.keys.elementAt(index);
            final amount = spendingByCategory[category]!;
            final percentage = totalSpent > 0 ? (amount / totalSpent) * 100 : 0.0;
            
            return _buildCategoryItem(
              context, 
              appState, 
              category, 
              amount, 
              percentage.toDouble(),
            );
          },
        ),
      ],
    );
  }

  Widget _buildCategoryItem(
    BuildContext context,
    AppState appState,
    TransactionCategory category,
    double amount,
    double percentage,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            // Category Icon
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: _getCategoryColor(category).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                _getCategoryIcon(category),
                color: _getCategoryColor(category),
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            
            // Category Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _getCategoryName(category, appState.isArabic),
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${percentage.toStringAsFixed(1)}% of total',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                    ),
                  ),
                ],
              ),
            ),
            
            // Amount
            CurrencyText(
              amount: amount,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyAnalytics(BuildContext context, AppState appState) {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: Column(
        children: [
          Icon(
            Icons.analytics_outlined,
            size: 64,
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'No spending data available',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Start making transactions to see your spending analytics',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Color _getCategoryColor(TransactionCategory category) {
    switch (category) {
      case TransactionCategory.food:
        return AppColors.warning;
      case TransactionCategory.transportation:
        return AppColors.info;
      case TransactionCategory.shopping:
        return AppColors.primaryBlue;
      case TransactionCategory.entertainment:
        return AppColors.success;
      case TransactionCategory.utilities:
        return AppColors.error;
      case TransactionCategory.healthcare:
        return Colors.purple;
      case TransactionCategory.education:
        return Colors.teal;
      case TransactionCategory.travel:
        return Colors.orange;
      case TransactionCategory.salary:
        return AppColors.success;
      case TransactionCategory.transfer:
        return AppColors.primaryBlue;
      case TransactionCategory.other:
        return Colors.grey;
    }
  }

  IconData _getCategoryIcon(TransactionCategory category) {
    switch (category) {
      case TransactionCategory.food:
        return Icons.restaurant;
      case TransactionCategory.transportation:
        return Icons.directions_car;
      case TransactionCategory.shopping:
        return Icons.shopping_bag;
      case TransactionCategory.entertainment:
        return Icons.movie;
      case TransactionCategory.utilities:
        return Icons.electric_bolt;
      case TransactionCategory.healthcare:
        return Icons.medical_services;
      case TransactionCategory.education:
        return Icons.school;
      case TransactionCategory.travel:
        return Icons.flight;
      case TransactionCategory.salary:
        return Icons.work;
      case TransactionCategory.transfer:
        return Icons.swap_horiz;
      case TransactionCategory.other:
        return Icons.more_horiz;
    }
  }

  String _getCategoryName(TransactionCategory category, bool isArabic) {
    switch (category) {
      case TransactionCategory.food:
        return isArabic ? 'طعام' : 'Food';
      case TransactionCategory.transportation:
        return isArabic ? 'مواصلات' : 'Transportation';
      case TransactionCategory.shopping:
        return isArabic ? 'تسوق' : 'Shopping';
      case TransactionCategory.entertainment:
        return isArabic ? 'ترفيه' : 'Entertainment';
      case TransactionCategory.utilities:
        return isArabic ? 'مرافق' : 'Utilities';
      case TransactionCategory.healthcare:
        return isArabic ? 'رعاية صحية' : 'Healthcare';
      case TransactionCategory.education:
        return isArabic ? 'تعليم' : 'Education';
      case TransactionCategory.travel:
        return isArabic ? 'سفر' : 'Travel';
      case TransactionCategory.salary:
        return isArabic ? 'راتب' : 'Salary';
      case TransactionCategory.transfer:
        return isArabic ? 'تحويل' : 'Transfer';
      case TransactionCategory.other:
        return isArabic ? 'أخرى' : 'Other';
    }
  }
}

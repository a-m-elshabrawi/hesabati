import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../constants/app_colors.dart';
import 'login_screen.dart';
import 'two_factor_auth_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, appState, child) {
        return Scaffold(
          appBar: AppBar(
            title: Text(appState.getLocalizedString('settings')),
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // Appearance Section
              _buildSectionHeader(context, 'Appearance'),
              _buildDarkThemeToggle(context, appState),
              const SizedBox(height: 24),
              
              // Language Section
              _buildSectionHeader(context, 'Language'),
              _buildLanguageSelector(context, appState),
              const SizedBox(height: 24),
              
              // Security Section
              _buildSectionHeader(context, 'Security'),
              _buildBiometricToggle(context, appState),
              _buildTwoFactorToggle(context, appState),
              if (appState.useTwoFactor) _buildTestTwoFactorButton(context, appState),
              const SizedBox(height: 24),
              
              // App Info Section
              _buildSectionHeader(context, 'App Information'),
              _buildAppInfo(context, appState),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w600,
          color: AppColors.primaryBlue,
        ),
      ),
    );
  }

  Widget _buildDarkThemeToggle(BuildContext context, AppState appState) {
    return Card(
      child: SwitchListTile(
        title: Text(appState.getLocalizedString('darkTheme')),
        subtitle: const Text('Toggle between light and dark theme'),
        value: appState.isDarkMode,
        onChanged: (value) {
          appState.toggleDarkMode();
        },
        activeThumbColor: AppColors.primaryBlue,
        secondary: Icon(
          appState.isDarkMode ? Icons.dark_mode : Icons.light_mode,
          color: AppColors.primaryBlue,
        ),
      ),
    );
  }

  Widget _buildLanguageSelector(BuildContext context, AppState appState) {
    return Card(
      child: ListTile(
        leading: const Icon(
          Icons.language,
          color: AppColors.primaryBlue,
        ),
        title: Text(appState.getLocalizedString('language')),
        subtitle: Text(
          appState.isArabic ? 'العربية' : 'English',
        ),
        trailing: DropdownButton<String>(
          value: appState.isArabic ? 'ar' : 'en',
          underline: const SizedBox(),
          items: [
            DropdownMenuItem(
              value: 'en',
              child: Text(appState.getLocalizedString('english')),
            ),
            DropdownMenuItem(
              value: 'ar',
              child: Text(appState.getLocalizedString('arabic')),
            ),
          ],
          onChanged: (value) {
            if (value == 'ar' && !appState.isArabic) {
              appState.toggleLanguage();
            } else if (value == 'en' && appState.isArabic) {
              appState.toggleLanguage();
            }
          },
        ),
      ),
    );
  }

  Widget _buildBiometricToggle(BuildContext context, AppState appState) {
    return Card(
      child: SwitchListTile(
        title: Text(appState.getLocalizedString('biometricAuth')),
        subtitle: const Text('Use fingerprint or face recognition for transfers (takes precedence over 2FA)'),
        value: appState.useBiometric,
        onChanged: (value) {
          appState.toggleBiometric();
        },
        activeThumbColor: AppColors.primaryBlue,
        secondary: const Icon(
          Icons.fingerprint,
          color: AppColors.primaryBlue,
        ),
      ),
    );
  }

  Widget _buildTwoFactorToggle(BuildContext context, AppState appState) {
    return Card(
      child: SwitchListTile(
        title: Text(appState.getLocalizedString('twoFactorAuth')),
        subtitle: const Text('Enable two-factor authentication for transfers (only when biometric is disabled)'),
        value: appState.useTwoFactor,
        onChanged: (value) {
          appState.toggleTwoFactor();
        },
        activeThumbColor: AppColors.primaryBlue,
        secondary: const Icon(
          Icons.security,
          color: AppColors.primaryBlue,
        ),
      ),
    );
  }

  Widget _buildTestTwoFactorButton(BuildContext context, AppState appState) {
    return Card(
      child: ListTile(
        leading: const Icon(
          Icons.security,
          color: AppColors.primaryBlue,
        ),
        title: const Text('Test Two-Factor Authentication'),
        subtitle: const Text('Try the 2FA screen'),
        trailing: const Icon(Icons.arrow_forward_ios),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const TwoFactorAuthScreen()),
          );
        },
      ),
    );
  }

  Widget _buildAppInfo(BuildContext context, AppState appState) {
    return Card(
      child: Column(
        children: [
          const ListTile(
            leading: Icon(
              Icons.info_outline,
              color: AppColors.primaryBlue,
            ),
            title: Text('App Version'),
            subtitle: Text('1.0.0'),
          ),
          const Divider(height: 1),
          // Logout
          ListTile(
            leading: const Icon(
              Icons.logout,
              color: AppColors.primaryBlue,
            ),
            title: Text(appState.getLocalizedString('logout')),
            onTap: () async {
              final confirmed = await showDialog<bool>(
                context: context,
                builder: (context) => AlertDialog(
                  title: Text(appState.getLocalizedString('logout')),
                  content: Text(appState.getLocalizedString('confirmLogout')),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context, false),
                      child: Text(appState.getLocalizedString('cancel')),
                    ),
                    TextButton(
                      onPressed: () => Navigator.pop(context, true),
                      child: Text(appState.getLocalizedString('logout')),
                    ),
                  ],
                ),
              );
              if (confirmed == true) {
                appState.logout();
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false,
                );
              }
            },
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(
              Icons.description,
              color: AppColors.primaryBlue,
            ),
            title: const Text('Terms of Service'),
            onTap: () {
              _showTermsDialog(context);
            },
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(
              Icons.privacy_tip,
              color: AppColors.primaryBlue,
            ),
            title: const Text('Privacy Policy'),
            onTap: () {
              _showPrivacyDialog(context);
            },
          ),
        ],
      ),
    );
  }

  void _showTermsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Terms of Service'),
        content: const SingleChildScrollView(
          child: Text(
            'This is a demo application for educational purposes. '
            'No real financial transactions are processed. '
            'All data is stored locally and is not transmitted to any servers.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showPrivacyDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Privacy Policy'),
        content: const SingleChildScrollView(
          child: Text(
            'This demo app does not collect, store, or transmit any personal data. '
            'All information is stored locally on your device and is not shared with any third parties. '
            'The app does not require internet connectivity.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}

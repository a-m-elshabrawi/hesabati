import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/transaction.dart';
import '../models/account.dart';
import '../providers/app_state.dart';
import '../constants/app_colors.dart';
import '../widgets/currency_text.dart';

class TransactionDetailsScreen extends StatelessWidget {
  final Transaction transaction;

  const TransactionDetailsScreen({super.key, required this.transaction});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppState>(
      builder: (context, appState, child) {
        final account = appState.getAccountById(transaction.accountId);
        
        return Scaffold(
          appBar: AppBar(
            title: const Text('Transaction Details'),
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Transaction Summary Card
                _buildTransactionSummary(context, appState),
                const SizedBox(height: 24),
                
                // Transaction Details
                _buildTransactionDetails(context, appState, account),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildTransactionSummary(BuildContext context, AppState appState) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // Category Icon
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: _getCategoryColor(transaction.category).withOpacity(0.1),
                borderRadius: BorderRadius.circular(40),
              ),
              child: Icon(
                _getCategoryIcon(transaction.category),
                color: _getCategoryColor(transaction.category),
                size: 40,
              ),
            ),
            const SizedBox(height: 16),
            
            // Amount
            CurrencyText(
              amount: transaction.amount,
              showSign: true,
              style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            
            // Transaction Title
            Text(
              _getTransactionTitle(transaction, appState.isArabic),
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            
            // Category
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: _getCategoryColor(transaction.category).withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: _getCategoryColor(transaction.category).withOpacity(0.3),
                ),
              ),
              child: Text(
                _getCategoryName(transaction.category, appState.isArabic),
                style: TextStyle(
                  color: _getCategoryColor(transaction.category),
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTransactionDetails(BuildContext context, AppState appState, Account? account) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Transaction Details',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 20),
            
            // Date and Time
            _buildDetailRow(
              context,
              'Date & Time',
              _formatDateTime(transaction.dateTime),
              Icons.schedule,
            ),
            const SizedBox(height: 16),
            
            // Account
            if (account != null)
              _buildDetailRow(
                context,
                'Account',
                '${account.name} (${account.maskedNumber})',
                Icons.account_balance_wallet,
              ),
            const SizedBox(height: 16),
            
            // Transaction Type
            _buildDetailRow(
              context,
              'Type',
              transaction.isIncome ? 'Income' : 'Expense',
              transaction.isIncome ? Icons.trending_up : Icons.trending_down,
            ),
            const SizedBox(height: 16),
            
            // Description (optional)
            if (_extractUserDescription(transaction) != null) ...[
              _buildDetailRow(
                context,
                'Description',
                _extractUserDescription(transaction)!,
                Icons.description,
              ),
              const SizedBox(height: 16),
            ],
            
            // Transaction ID
            _buildDetailRow(
              context,
              'Transaction ID',
              transaction.id,
              Icons.receipt,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(BuildContext context, String label, String value, IconData icon) {
    return Row(
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: AppColors.primaryBlue.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            color: AppColors.primaryBlue,
            size: 20,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                value,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Color _getCategoryColor(TransactionCategory category) {
    switch (category) {
      case TransactionCategory.food:
        return AppColors.warning;
      case TransactionCategory.transportation:
        return AppColors.info;
      case TransactionCategory.shopping:
        return AppColors.primaryBlue;
      case TransactionCategory.entertainment:
        return AppColors.success;
      case TransactionCategory.utilities:
        return AppColors.error;
      case TransactionCategory.healthcare:
        return Colors.purple;
      case TransactionCategory.education:
        return Colors.teal;
      case TransactionCategory.travel:
        return Colors.orange;
      case TransactionCategory.salary:
        return AppColors.success;
      case TransactionCategory.transfer:
        return AppColors.primaryBlue;
      case TransactionCategory.other:
        return Colors.grey;
    }
  }

  IconData _getCategoryIcon(TransactionCategory category) {
    switch (category) {
      case TransactionCategory.food:
        return Icons.restaurant;
      case TransactionCategory.transportation:
        return Icons.directions_car;
      case TransactionCategory.shopping:
        return Icons.shopping_bag;
      case TransactionCategory.entertainment:
        return Icons.movie;
      case TransactionCategory.utilities:
        return Icons.electric_bolt;
      case TransactionCategory.healthcare:
        return Icons.medical_services;
      case TransactionCategory.education:
        return Icons.school;
      case TransactionCategory.travel:
        return Icons.flight;
      case TransactionCategory.salary:
        return Icons.work;
      case TransactionCategory.transfer:
        return Icons.swap_horiz;
      case TransactionCategory.other:
        return Icons.more_horiz;
    }
  }

  String _getCategoryName(TransactionCategory category, bool isArabic) {
    switch (category) {
      case TransactionCategory.food:
        return isArabic ? 'طعام' : 'Food';
      case TransactionCategory.transportation:
        return isArabic ? 'مواصلات' : 'Transportation';
      case TransactionCategory.shopping:
        return isArabic ? 'تسوق' : 'Shopping';
      case TransactionCategory.entertainment:
        return isArabic ? 'ترفيه' : 'Entertainment';
      case TransactionCategory.utilities:
        return isArabic ? 'مرافق' : 'Utilities';
      case TransactionCategory.healthcare:
        return isArabic ? 'رعاية صحية' : 'Healthcare';
      case TransactionCategory.education:
        return isArabic ? 'تعليم' : 'Education';
      case TransactionCategory.travel:
        return isArabic ? 'سفر' : 'Travel';
      case TransactionCategory.salary:
        return isArabic ? 'راتب' : 'Salary';
      case TransactionCategory.transfer:
        return isArabic ? 'تحويل' : 'Transfer';
      case TransactionCategory.other:
        return isArabic ? 'أخرى' : 'Other';
    }
  }

  String _getTransactionTitle(Transaction transaction, bool isArabic) {
    switch (transaction.category) {
      case TransactionCategory.transfer:
        // For transfers, show a clean title without the description
        return isArabic ? 'تحويل' : 'Transfer';
      case TransactionCategory.salary:
        return isArabic ? 'إيداع راتب' : 'Salary Deposit';
      case TransactionCategory.food:
        return isArabic ? 'مشتريات طعام' : 'Food Purchase';
      case TransactionCategory.transportation:
        return isArabic ? 'نفقات مواصلات' : 'Transportation';
      case TransactionCategory.shopping:
        return isArabic ? 'تسوق' : 'Shopping';
      case TransactionCategory.entertainment:
        return isArabic ? 'ترفيه' : 'Entertainment';
      case TransactionCategory.utilities:
        return isArabic ? 'فواتير مرافق' : 'Utilities';
      case TransactionCategory.healthcare:
        return isArabic ? 'رعاية صحية' : 'Healthcare';
      case TransactionCategory.education:
        return isArabic ? 'تعليم' : 'Education';
      case TransactionCategory.travel:
        return isArabic ? 'سفر' : 'Travel';
      case TransactionCategory.other:
        return isArabic ? 'معاملة أخرى' : 'Other Transaction';
    }
  }

  String? _extractUserDescription(Transaction transaction) {
    // For transfer transactions, extract the user description if present
    if (transaction.category == TransactionCategory.transfer) {
      final description = transaction.description;
      if (description.contains(': ')) {
        final parts = description.split(': ');
        if (parts.length > 1) {
          return parts.sublist(1).join(': '); // Join in case description contains colons
        }
      }
      return null; // No user description found
    }
    
    // For non-transfer transactions, return the full description
    return transaction.description;
  }

  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    String dateString;
    if (difference.inDays == 0) {
      dateString = 'Today';
    } else if (difference.inDays == 1) {
      dateString = 'Yesterday';
    } else if (difference.inDays < 7) {
      dateString = '${difference.inDays} days ago';
    } else {
      dateString = '${dateTime.day}/${dateTime.month}/${dateTime.year}';
    }

    final timeString = '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    
    return '$dateString at $timeString';
  }
}
